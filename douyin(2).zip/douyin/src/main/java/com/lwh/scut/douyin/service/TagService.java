package com.lwh.scut.douyin.service;

import com.baomidou.mybatisplus.extension.service.IService;
import com.lwh.scut.douyin.dto.Result;
import com.lwh.scut.douyin.entity.Tag;

public interface TagService extends IService<Tag> {
    Result saveTag(String tag);

    Result deleteTag(Long id);

    Result listTag();
}
