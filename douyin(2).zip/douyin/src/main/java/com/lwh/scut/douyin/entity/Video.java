package com.lwh.scut.douyin.entity;

import com.baomidou.mybatisplus.annotation.IdType;
import com.baomidou.mybatisplus.annotation.TableField;
import com.baomidou.mybatisplus.annotation.TableId;
import com.baomidou.mybatisplus.annotation.TableName;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.EqualsAndHashCode;
import lombok.NoArgsConstructor;
import lombok.experimental.Accessors;

import java.io.Serializable;
import java.time.LocalDateTime;

@Data
@AllArgsConstructor
@NoArgsConstructor
@EqualsAndHashCode(callSuper = false)
@Accessors(chain = true)
@TableName("tb_video")
public class Video implements Serializable {
    @TableId(value = "id", type = IdType.AUTO)
    private Long id;
    private Long userId;
    private int tagId;
    private String url;
    private String title;
    private Integer countOfLiked;
    private Integer countOfCollect;
    private Integer countOfComment;
    private Integer countOfBroadcast;

    @TableField(exist = false)
    private String senderName;// 发布者昵称
    @TableField(exist = false)
    private String senderImage;// 发布者头像
    @TableField(exist = false)
    private Boolean isLiked;// 当前用户是否已经点赞
    @TableField(exist = false)
    private Boolean isCollected;// 当前用户是否已经收藏

    private LocalDateTime createTime;
    private LocalDateTime updateTime;
}
