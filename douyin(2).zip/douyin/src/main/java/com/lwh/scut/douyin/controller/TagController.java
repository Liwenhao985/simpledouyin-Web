package com.lwh.scut.douyin.controller;

import com.lwh.scut.douyin.dto.Result;
import com.lwh.scut.douyin.service.TagService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

@RestController
@RequestMapping("/tag")
public class TagController {

    @Autowired
    private TagService tagService;

    // 添加标签
    @PostMapping("/add")
    public Result addTag(String  tag) {
        return tagService.saveTag( tag);
    }

    // 删除标签
    @DeleteMapping("/delete/{id}")
    public Result deleteTag(@PathVariable Long id) {
        return tagService.deleteTag(id);
    }

    // 展示标签列表
    @GetMapping("/list")
    public Result listTag() {
        return tagService.listTag();
    }
}
