package com.lwh.scut.douyin.service.impl;

import cn.hutool.json.JSONUtil;
import com.baomidou.mybatisplus.extension.service.impl.ServiceImpl;
import com.lwh.scut.douyin.dto.Result;
import com.lwh.scut.douyin.entity.Comment;
import com.lwh.scut.douyin.entity.Video;
import com.lwh.scut.douyin.mapper.CommentMapper;
import com.lwh.scut.douyin.service.CommentService;
import com.lwh.scut.douyin.service.UserService;
import com.lwh.scut.douyin.service.VideoService;
import com.lwh.scut.douyin.utils.UserHolder;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.redis.core.StringRedisTemplate;
import org.springframework.stereotype.Service;

import java.time.LocalDateTime;
import java.util.List;
import java.util.Set;
import java.util.concurrent.TimeUnit;

import static com.lwh.scut.douyin.utils.RedisConstants.*;

@Service
public class CommentServiceImpl extends ServiceImpl<CommentMapper, Comment> implements CommentService {

    @Autowired
    private UserService userService;
    @Autowired
    private VideoService videoService;
    @Autowired
    private StringRedisTemplate stringRedisTemplate;

    public static final Long BROADCAST_COUNT = 1000000L;

    @Override
    public Result addComment(Long videoId, String content) {
        // 1.封装comment对象
        Comment comment = newComment(videoId, content);
        // 2.保存到数据库
        boolean save = save(comment);
        // 3.判断保存成功
        if (!save) {
            return Result.error("评论失败");
        }
        // 4.判断视频的CountOfBroadcast是否大于100W（缓存热门视频评论）
        Video video = videoService.getById(videoId);
        if (video.getCountOfBroadcast() > BROADCAST_COUNT) {
            addRedis(videoId, comment.getId());
        }
        // 5.返回结果
        return Result.success("评论成功");
    }

    @Override
    public Result deleteComment(Long commentId) {
        // 一般前端就会显示是否可删除
        Long videoId  = getById(commentId).getVideoId();
        Long userId = UserHolder.get().getId();
        if (userId!=getById(commentId).getUserId()) {
            return Result.error("您没有权限删除该评论");
        }
        // 1.删除数据库记录
        boolean result = removeById(commentId);
        if (!result) {
            return Result.error("删除失败");
        }
        // 2.删除缓存
        Video video = videoService.getById(videoId);
        // 3.热门视频刷新redis数据
        if(video.getCountOfBroadcast() > 1000000){
            String key = COMMENT_KEY + videoId;
            stringRedisTemplate.opsForZSet().remove(key, commentId.toString());
        }
        String key2 = COMMENT_LIKE_KEY + commentId;
        stringRedisTemplate.opsForZSet().remove(key2, commentId.toString());
        // 4.返回结果
        return Result.success("删除成功");
    }

    @Override
    public Result listComment(Long videoId) {
        // 1.非热门视频直接查数据库
        Video video = videoService.getById(videoId);
        if(video.getCountOfComment() < 1000000){
            List<Comment> list = query().eq("video_id", videoId).list();
            // 给每条评论添加用户信息
            for (Comment comment : list) {
                comment.setSenderName(userService.getById(comment.getUserId()).getNickName());
                comment.setSenderImage(userService.getById(comment.getUserId()).getImage());
                Double score = stringRedisTemplate.opsForZSet().score(COMMENT_LIKE_KEY, comment.getUserId().toString());
                comment.setIsLiked(score!=null);
            }
            return Result.success(list);
        }
        // 2.热门视频先查询redis
        String key = COMMENT_KEY + videoId;
        Set<String> range = stringRedisTemplate.opsForZSet().range(key, 0, -1);
        if (range == null || range.isEmpty()){
            List<Comment> list = query().eq("video_id", videoId).list();
            createRedis(list, videoId);
            return Result.success(list);
        }
        // 3.缓存数据转换成List
        List<Comment> list = range.stream().map(s -> JSONUtil.toBean(s, Comment.class)).toList();
        // 4.每次有人看就刷新redis过期时间
        stringRedisTemplate.expire(key, COMMENT_TTL, TimeUnit.MINUTES);
        return Result.success(list);
    }

    @Override
    public Result likeComment(Long commentId, Boolean isLike) {
        // 获取当前用户id
        Long userId = UserHolder.get().getId();
        // 1.刷新comment
        refreshCommentLike(commentId,isLike);
        // 2.刷新热门视频缓存
        Comment comment = getById(commentId);
        Video video = videoService.getById(comment.getVideoId());
        if(video.getCountOfBroadcast()>1000000){
            // 3.刷新redis对应comment的score值
            String key = COMMENT_KEY + video.getId();
            stringRedisTemplate.opsForZSet().add(key, commentId.toString(), comment.getCountOfLiked());
        }
        // 4.记录该条评论点赞过的用户
        String key2 = COMMENT_LIKE_KEY + commentId;
        stringRedisTemplate.opsForZSet().add(key2, String.valueOf(userId), System.currentTimeMillis());
        return Result.success();
    }

    @Override
    public Result isLiked(Long commentId) {
        // 1.获取当前用户id
        Long userId = UserHolder.get().getId();
        // 2.判断该用户是否点赞过该条评论
        String key = COMMENT_LIKE_KEY + commentId;
        return stringRedisTemplate.opsForZSet().score(key, String.valueOf(userId)) != null ? Result.success(true) : Result.success(false);
    }

    @Override
    public Result replyComment(Long commentId, String content) {
        // 1.封装comment对象
        Comment comment = newReplyComment(commentId, content);
        // 2.保存到数据库
        boolean save = save(comment);
        // 3.判断保存成功
        if (!save) {
            return Result.error("回复评论失败");
        }
        // 4.热门视频则添加到redis
        Long videoId =comment.getVideoId();
        if(videoService.getById(videoId).getCountOfBroadcast()>1000000){
            addRedis(videoId, comment.getId());
        }
        return Result.success("回复评论成功");
    }

    @Override
    public Result reportComment(Long commentId, String reason) {
        // 1.保存举报信息
        Comment comment = getById(commentId);
        comment.setStatus(1);
        comment.setReason(reason);
        // 2.保存
        boolean update = updateById(comment);
        return update ? Result.success("举报成功") : Result.error("举报失败");
    }

    private Comment newComment(Long videoId,String  content) {
        Long userId = UserHolder.get().getId() ;
        Comment comment = new Comment();
        comment.setUserId(userId);
        comment.setVideoId(videoId);
        comment.setContent(content);
        comment.setCreateTime(LocalDateTime.now());
        comment.setUpdateTime(LocalDateTime.now());
        return comment;
    }

    private Comment newReplyComment(Long commentId,String  content) {
        Long userId = UserHolder.get().getId() ;
        // 获取videoId
        Long videoId = getById(commentId).getVideoId();
        Comment comment = new Comment();
        comment.setUserId(userId);
        comment.setVideoId(videoId);
        comment.setParentId(commentId);
        comment.setContent(content);
        comment.setCreateTime(LocalDateTime.now());
        comment.setUpdateTime(LocalDateTime.now());
        return comment;
    }

    private void refreshCommentLike(Long commentId, Boolean isLike) {
        Comment comment = getById(commentId);
        if (comment == null) {
            return;
        }
        // 判断是点赞还是取消点赞
        if(isLike){
            comment.setCountOfLiked(comment.getCountOfLiked() + 1);
        }else{
            comment.setCountOfLiked(comment.getCountOfLiked() - 1);
        }
        updateById(comment);
    }

    private void createRedis(List< Comment> list,Long videoId){
        String key = COMMENT_KEY + videoId;
        for (Comment comment : list) {
            stringRedisTemplate.opsForZSet().add(key, comment.getId().toString(), comment.getCountOfLiked());
        }
        stringRedisTemplate.expire(key, COMMENT_TTL, TimeUnit.MINUTES);
    }

    private void addRedis(Long videoId,Long commentId) {
        String key = COMMENT_KEY + videoId;
        // 1.使用ZSET缓存到redis，score值是点赞数
        stringRedisTemplate.opsForZSet().add(key,commentId.toString(),0);
        // 2.设置过期时间10分钟
        stringRedisTemplate.expire(key, COMMENT_TTL, TimeUnit.MINUTES);
    }
}
