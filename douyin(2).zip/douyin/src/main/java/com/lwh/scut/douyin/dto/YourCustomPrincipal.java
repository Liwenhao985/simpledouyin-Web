package com.lwh.scut.douyin.dto;

import lombok.AllArgsConstructor;
import lombok.Data;

import java.security.Principal;

@Data
@AllArgsConstructor
public class YourCustomPrincipal implements Principal {

    private final Long id;
    private final String name;
    private final String image;

    @Override
    public String getName() {
        return name;
    }
}