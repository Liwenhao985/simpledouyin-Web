package com.lwh.scut.douyin.service.impl;

import cn.hutool.core.bean.BeanUtil;
import cn.hutool.core.bean.copier.CopyOptions;
import cn.hutool.core.util.RandomUtil;
import com.baomidou.mybatisplus.core.conditions.query.QueryWrapper;
import com.baomidou.mybatisplus.extension.service.impl.ServiceImpl;
import com.lwh.scut.douyin.dto.Result;
import com.lwh.scut.douyin.dto.UserDTO;
import com.lwh.scut.douyin.dto.UserInfo;
import com.lwh.scut.douyin.entity.User;
import com.lwh.scut.douyin.mapper.UserMapper;
import com.lwh.scut.douyin.service.UserService;
import com.lwh.scut.douyin.utils.*;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.redis.connection.BitFieldSubCommands;
import org.springframework.data.redis.core.StringRedisTemplate;
import org.springframework.stereotype.Service;

import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.concurrent.TimeUnit;

import static com.lwh.scut.douyin.utils.RedisConstants.*;

@Slf4j
@Service
public class UserServiceImpl extends ServiceImpl<UserMapper, User> implements UserService {

    @Autowired
    private UserMapper userMapper;
    @Autowired
    private StringRedisTemplate stringRedisTemplate;

    public static String LOGIN_CAPTCHA;
    public static String REGISTER_CAPTCHA;
    @Override
    public Result sendCodeToLogin(String phone) {
        // 1.校验手机号
        if (RegexUtils.isPhoneInvalid(phone)) {
            return Result.error("手机号格式错误");
        }
        // 2.生成验证码
        LOGIN_CAPTCHA= RandomUtil.randomNumbers(6);
        // 3.保存验证码到reids,2分钟有效
        stringRedisTemplate.opsForValue().set(LOGIN_CODE_KEY+phone,LOGIN_CAPTCHA, LOGIN_CODE_TTL, TimeUnit.MINUTES);
        // 5.返回验证码，日志打印模拟
        log.debug("发送验证码成功：{}", LOGIN_CAPTCHA);
        return Result.success();
    }

    @Override
    public Result sendCodeToRegister(String phone){
        // 1.校验手机号
        if (RegexUtils.isPhoneInvalid(phone)) {
            return Result.error("手机号格式错误");
        }
        // 2.生成验证码
        REGISTER_CAPTCHA= RandomUtil.randomNumbers(6);
        // 3.保存验证码到reids,2分钟有效
        stringRedisTemplate.opsForValue().set(REGISTER_CODE_KEY+phone, REGISTER_CAPTCHA, REGISTER_CODE_TTL, TimeUnit.MINUTES);
        // 5.返回验证码，日志打印模拟
        log.debug("发送验证码成功：{}", REGISTER_CAPTCHA);
        return Result.success();
    }

    @Override
    public Result loginByCode(String phone, String code) {
        // 1.校验手机号
        if (RegexUtils.isPhoneInvalid(phone)) {
            return Result.error("手机号格式错误");
        }
        // 2.校验验证码
        String cacheCode = stringRedisTemplate.opsForValue().get(LOGIN_CODE_KEY + phone);
        // 2.1.验证码错误或过期
        if (cacheCode == null || !cacheCode.equals(code)) {
            return Result.error("验证码错误");
        }
        // 2.2.验证码正确，删除缓存
        stringRedisTemplate.delete(LOGIN_CODE_KEY + phone);
        // 3.查询用户是否存在
        User user = userMapper.selectOne(new QueryWrapper<User>().eq("phone", phone));
        if (user == null) {
            // 4.不存在
            return Result.error("用户不存在");
        }
        // 转换成UserDTO
        UserDTO userDTO = BeanUtil.copyProperties(user, UserDTO.class);
        // 5.创建JWT令牌
        String token = JWTUtil.createToken(BeanUtil.beanToMap(userDTO));
        // 6.存储到redis中
        String tokenKey = RedisConstants.LOGIN_USER_KEY + token;
        Map<String, Object> userMap = BeanUtil.beanToMap(userDTO,new HashMap<>(),
                CopyOptions.create()
                        .setIgnoreNullValue(true)
                        .setFieldValueEditor((fieldName, fieldValue) -> fieldValue.toString()));
        stringRedisTemplate.opsForHash().putAll(tokenKey, BeanUtil.beanToMap(userMap));
        // 6.1.设置有效期
        // key会在每次访问时会在刷新拦截器自动刷新过期时长
        stringRedisTemplate.expire(tokenKey, RedisConstants.LOGIN_USER_TTL, TimeUnit.MINUTES);

        return Result.success( token);
    }

    @Override
    public Result loginByPassword(String phone, String password) {
        // 1.校验手机号
        if (RegexUtils.isPhoneInvalid(phone)) {
            return Result.error("手机号格式错误");
        }
        // 2.查询用户是否存在
        User user = userMapper.selectOne(new QueryWrapper<User>().eq("phone", phone));
        if (user == null) {
            // 3.不存在
            return Result.error("用户不存在");
        }
        // 4.校验密码
        if (!PasswordEncoder.matches(user.getPassword(), password)) {
            return Result.error("密码错误");
        }
        // 转换成UserDTO
        UserDTO userDTO = BeanUtil.copyProperties(user, UserDTO.class);
        // 5.创建JWT令牌
        String token = JWTUtil.createToken(BeanUtil.beanToMap(userDTO));
        // 6.存储到redis中
        String tokenKey = RedisConstants.LOGIN_USER_KEY + token;
        Map<String, Object> userMap = BeanUtil.beanToMap(userDTO,new HashMap<>(),
                CopyOptions.create()
                        .setIgnoreNullValue(true)
                        .setFieldValueEditor((fieldName, fieldValue) -> fieldValue.toString()));
        stringRedisTemplate.opsForHash().putAll(tokenKey, BeanUtil.beanToMap(userMap));
        // 6.1.设置有效期
        // key会在每次访问时会在刷新拦截器自动刷新过期时长
        stringRedisTemplate.expire(tokenKey, RedisConstants.LOGIN_USER_TTL, TimeUnit.MINUTES);

        return Result.success( token);
    }

    @Override
    public Result register(String phone, String code) {
        // 1.检验手机号合法性
        if (RegexUtils.isPhoneInvalid(phone)) {
            return Result.error("手机号格式错误");
        }
        // 2.校验验证码
        String cacheCode = stringRedisTemplate.opsForValue().get(REGISTER_CODE_KEY + phone);
        if (cacheCode == null || !cacheCode.equals(code)) {
            return Result.error("验证码错误");
        }
        // 3.查询用户是否存在
        User user = userMapper.selectOne(new QueryWrapper<User>().eq("phone", phone));
        if (user != null) {
            return Result.error("用户已存在,请直接登录");
        }
        // 4.保存用户
        user = createUserWithPhone(phone);
        save(user);
        // 5.保存UserDTO，方便后续操作
        UserDTO userDTO = new UserDTO();
        userDTO.setId(user.getId());
        UserHolder.set(userDTO);
        return Result.success("注册成功");
    }

    @Override
    public Result registerInfo(UserInfo userInfo){
        // 1.保存用户信息
        User user = getNewUser(userInfo);
        userMapper.updateById(user);
        // 2.把user转换成UserDTO
        UserDTO userDTO = BeanUtil.copyProperties(user, UserDTO.class);
        UserHolder.set(userDTO);
        // 3.创建JWT令牌
        String token = JWTUtil.createToken(BeanUtil.beanToMap(userDTO));
        // 4.存储到redis中
        String tokenKey = RedisConstants.LOGIN_USER_KEY + token;
        Map<String, Object> userMap = BeanUtil.beanToMap(userDTO,new HashMap<>(),
                CopyOptions.create()
                        .setIgnoreNullValue(true)
                        .setFieldValueEditor((fieldName, fieldValue) -> fieldValue.toString()));
        stringRedisTemplate.opsForHash().putAll(tokenKey, BeanUtil.beanToMap(userMap));
        // 4.1.设置有效期
        // key会在每次访问时会在刷新拦截器自动刷新过期时长
        stringRedisTemplate.expire(tokenKey, RedisConstants.LOGIN_USER_TTL, TimeUnit.MINUTES);

        return Result.success( token);
    }

    @Override
    public Result queryUserById(Long userId){
        // 查询
        User user = getById(userId);
        if (user == null) {
            return Result.success();
        }
        UserDTO userDTO = BeanUtil.copyProperties(user, UserDTO.class);
        // 返回
        return Result.success(userDTO);
    }

    @Override
    public Result me() {
        // 1.获取当前登录用户ID
        long userId = UserHolder.get().getId();
        // 2.根据用户ID查询用户信息
        User user = getById(userId);

        return Result.success(user);
    }

    @Override
    public Result updateInfo(UserInfo userInfo){
        // 1.封装user对象
        User user = getNewUser(userInfo);
        // 2.更新用户信息
        return userMapper.updateById(user) > 0 ? Result.success("更改信息成功") : Result.error("更改信息失败");
    }

    @Override
    public Result sign(){
        // 1.获取当前登录用户ID
        long userId = UserHolder.get().getId();
        // 2.获取当前月份
        String now = LocalDateTime.now().format(DateTimeFormatter.ofPattern("yyyyMM"));
        // 3.拼接key
        String key = USER_SIGN_KEY + userId + ":" + now;
        // 4.利用redis的bitmap操作，将当前日期所在offset 置为1
        int offset = LocalDateTime.now().getDayOfMonth();
        Boolean isSign = stringRedisTemplate.opsForValue().setBit(key, offset, true);//这里用的是Boolean类型，可以节省内存空间
        // 5.设置缓存过期时间（本月剩余天数）
        stringRedisTemplate.expire(key, LocalDateTime.now().getMonth().length(true) - offset, TimeUnit.DAYS);
        return Boolean.TRUE.equals(isSign) ? Result.success("签到成功") : Result.error("签到失败");
    }

    @Override
    public Result signCount() {
        // 1.获取当前登录用户
        Long userId = UserHolder.get().getId();
        // 2.获取今天是本月的第几天
        int dayOfMonth = LocalDateTime.now().getDayOfMonth();
        // 3.拼接key
        String key = RedisConstants.USER_SIGN_KEY + userId;
        // 4.获取这个月的签到记录
        List<Long> result = stringRedisTemplate.opsForValue().bitField(
                key,
                BitFieldSubCommands.create().
                        get(BitFieldSubCommands.BitFieldType.unsigned(dayOfMonth)).valueAt(0));
        if (result == null || result.isEmpty()) {
            // 没有签到记录
            return Result.success(0);
        }
        // 5.从result中获取签到结果,算出本月签到的总天数
        Long signDays = result.get(0);
        int sum=0;
        while(true){
            if(signDays==0){
                break;
            }
            if((signDays & 1)==1){
                sum++;
            }
            signDays = signDays >> 1;
        }
        return Result.success(sum);
    }

    @Override
    public Result signCountContinuous(){
        // 1.获取当前登录用户
        Long userId = UserHolder.get().getId();
        // 2.获取今天是本月的第几天
        int dayOfMonth = LocalDateTime.now().getDayOfMonth();
        // 3.拼接key
        String key = RedisConstants.USER_SIGN_KEY + userId;
        // 4.获取这个月的签到记录
        List<Long> result = stringRedisTemplate.opsForValue().bitField(
                key,
                BitFieldSubCommands.create().
                        get(BitFieldSubCommands.BitFieldType.unsigned(dayOfMonth)).valueAt(0));
        if (result == null || result.isEmpty()) {
            // 没有签到记录
            return Result.success(0);
        }
        // 5.从result中获取签到结果,算出本月签到的总天数
        Long signDays = result.get(0);
        int sum=0;
        while(true){
            if((signDays & 1)==0){
                break;
            }else{
                sum++;
                signDays=signDays>>1;
            }
        }
        return Result.success(sum);
    }

    private User createUserWithPhone(String phone) {
        User user = new User();
        user.setPhone(phone);
        user.setCreateTime(LocalDateTime.now());
        user.setUpdateTime(LocalDateTime.now());
        return user;
    }

    private User getNewUser(UserInfo userInfo){
        // 1.把userInfo对象转换成User对象
        User user = BeanUtil.copyProperties(userInfo, User.class);
        // 2.获取userId
        Long userId = UserHolder.get().getId();
        user.setId(userId);
        user.setPassword(PasswordEncoder.encode(user.getPassword()));
        user.setUpdateTime(LocalDateTime.now());
        return user;
    }
}
