package com.lwh.scut.douyin.utils;

import com.lwh.scut.douyin.dto.UserDTO;

// 线程局部变量，用于保存当前登陆用户信息
public class UserHolder {
    private static final ThreadLocal<UserDTO> userHolder = new ThreadLocal<>();

    public static void set(UserDTO user) {
        userHolder.set(user);
    }

    public static UserDTO get() {
        return userHolder.get();
    }

    public static void remove() {
        userHolder.remove();
    }
}
