package com.lwh.scut.douyin.service;

import com.baomidou.mybatisplus.extension.service.IService;
import com.lwh.scut.douyin.entity.ChatMessage;

import java.util.List;

public interface ChatMessageService extends IService<ChatMessage> {
    ChatMessage processSendMessage(ChatMessage message);

    boolean isUserOnline(Long receiverId);

    void incrementUnreadCount(Long senderId,Long receiverId);

    List<ChatMessage> getChatHistoryOfUser(Long userId);

    void decrementUnreadCount(Long senderId,Long receiverId);

    Long getUnreadCountOfUser(Long senderId);

    Long getTotalUnreadCount(Long userId);
}
