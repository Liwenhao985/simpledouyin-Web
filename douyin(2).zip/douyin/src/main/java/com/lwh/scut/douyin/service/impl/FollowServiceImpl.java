package com.lwh.scut.douyin.service.impl;

import cn.hutool.core.bean.BeanUtil;
import cn.hutool.core.util.StrUtil;
import com.baomidou.mybatisplus.core.conditions.query.QueryWrapper;
import com.baomidou.mybatisplus.extension.service.impl.ServiceImpl;
import com.lwh.scut.douyin.dto.Result;
import com.lwh.scut.douyin.dto.UserDTO;
import com.lwh.scut.douyin.entity.Follow;
import com.lwh.scut.douyin.mapper.FollowMapper;
import com.lwh.scut.douyin.service.FollowService;
import com.lwh.scut.douyin.service.UserService;
import com.lwh.scut.douyin.utils.UserHolder;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.redis.core.StringRedisTemplate;
import org.springframework.stereotype.Service;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import java.util.Set;
import java.util.stream.Collectors;

import static com.lwh.scut.douyin.utils.RedisConstants.FOLLOW_KEY;

@Service
public class FollowServiceImpl extends ServiceImpl<FollowMapper, Follow> implements FollowService {

    @Autowired
    private UserService userService;
    @Autowired
    private StringRedisTemplate stringRedisTemplate;

    @Override
    public Result follow(Long userId,Boolean isFollow) {
        // 1.获取当前登录用户ID
        long myId = UserHolder.get().getId();
        if (isFollow){
            // 2.true,建立关注
            Follow follow = new Follow();
            follow.setUserId(myId);
            follow.setFollowId(userId);
            // 3.保存到数据库
            boolean result = save(follow);
            // 4.保存成功则保存至redis(SET保存）
            if (result){
                stringRedisTemplate.opsForSet().add(FOLLOW_KEY + myId,userId.toString());
            }
            return result ? Result.success("关注成功") : Result.error("关注失败");
        }else{
            // 2.false,取消关注
            boolean isSuccess = remove(new QueryWrapper<Follow>().eq("user_id", myId).eq("follow_id", userId));
            // 3.取消成功则删除redis
            if (isSuccess) {
                stringRedisTemplate.opsForSet().remove(FOLLOW_KEY + myId,userId.toString());
            }
            return isSuccess ? Result.success("取消关注成功") : Result.error("取消关注失败");
        }
    }

    @Override
    public Result isFollow(Long id) {
        // 1.获取当前登录用户ID
        long myId = UserHolder.get().getId();
        // 2.查询是否关注
        return Boolean.TRUE.equals(stringRedisTemplate.opsForSet().isMember(FOLLOW_KEY + myId, id.toString())) ?
                Result.success(true) : Result.success(false);
    }

    @Override
    public Result listFollowOfMe() {
        // 1.获取当前登录用户ID
        long myId = UserHolder.get().getId();
        // 2.查询
        return Result.success(query().eq("user_id", myId).list());
    }

    @Override
    public Result listFollowOfUserId(Long id) {
        return Result.success(query().eq("follow_id", id).list());
    }

    @Override
    public Result listCommonFollow(Long id) {
        // 1.获取当前登录用户ID
        long myId = UserHolder.get().getId();
        String key1 = FOLLOW_KEY + myId;
        String key2 =FOLLOW_KEY + id;
        // 2.求交集
        Set<String> intersect = stringRedisTemplate.opsForZSet().intersect(key1, key2);
        // 3.判断交集是否为空
        if (intersect == null || intersect.isEmpty()) {
            return Result.success(Collections.emptyList());
        }
        // 4.交集不为空，获取交集的ID
        List<Long> ids = intersect.stream().map(Long::valueOf).collect(Collectors.toList());
        // 5.因为共同关注不讲究顺序，所以直接用 listByIds即可
        List<UserDTO> userDTOS = userService.listByIds(ids)
                .stream()
                .map(user -> BeanUtil.copyProperties(user, UserDTO.class))//User映射成UserDTO，只会映射相同且非空的属性
                .collect(Collectors.toList());
        return Result.success(userDTOS);
    }
}
