package com.lwh.scut.douyin.utils;

import com.lwh.scut.douyin.dto.UserDTO;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import org.springframework.web.servlet.HandlerInterceptor;

import java.util.Map;

public class InterceptorUtil implements HandlerInterceptor {

    @Override
    public boolean preHandle(HttpServletRequest request, HttpServletResponse response, Object handler) throws Exception {
        // 从请求头中获取token
        String token = request.getHeader("Authorization");
        // 验证token
        if (token == null) {
            response.setStatus(401);
            return false;
        }
        // 解析token
        Map<String, Object> claims = JWTUtil.parseToken(token);
        // 验证token，token中无用户信息则不放行
        if (claims == null) {
            response.setStatus(401);
            return false;
        }
        // 设置用户信息
        request.setAttribute("claims", claims);
        return true;
    }

    @Override
    public void afterCompletion(HttpServletRequest request, HttpServletResponse response, Object handler, Exception ex) throws Exception {
        //资源访问完毕之后（即本次访问涉及的所有操作）删除ThreadLocal中的数据
        UserHolder.remove();
    }
}
