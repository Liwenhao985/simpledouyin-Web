package com.lwh.scut.douyin.utils;

import com.lwh.scut.douyin.dto.Result;
import lombok.extern.slf4j.Slf4j;
import org.springframework.dao.DuplicateKeyException;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.bind.annotation.RestControllerAdvice;

// 全局异常处理器
@Slf4j
@RestControllerAdvice
public class GlobalExceptionHandler {

    // 异常处理器
    @ExceptionHandler
    public Result doException(Exception ex) {
        log.error("服务器发生异常：{}", ex.getMessage());
        ex.printStackTrace();
        return Result.error("服务器故障，请联系管理员");
    }


    // 违反唯一约束，处理数据重复异常
    @ExceptionHandler
    public Result handleDuplicateKeyException(DuplicateKeyException ex) {
        // 获取报错信息
        String message=ex.getMessage();
        // 切割出有用信息
        int i=message.indexOf("Duplicate entry");
        String errMsg=message.substring(i);
        String[] arr=errMsg.split(" ");
        return Result.error(arr[2]+"已存在");
    }
}
