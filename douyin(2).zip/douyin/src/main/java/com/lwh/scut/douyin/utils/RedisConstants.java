package com.lwh.scut.douyin.utils;

//Redis的key常量
public class RedisConstants {
    public static final String LOGIN_CODE_KEY = "login:code:";
    public static final Long LOGIN_CODE_TTL = 2L;
    public static final String LOGIN_USER_KEY = "login:token:";
    public static final Long LOGIN_USER_TTL = 60L;

    public static final String REGISTER_CODE_KEY="register:code:";
    public static final Long REGISTER_CODE_TTL = 2L;

    public static final String USER_SIGN_KEY = "sign:user:";

    public static final String TAG_KEY = "tag:";
    public static final Long TAG_TTL = 60 * 60 * 24L;

    public static final String FOLLOW_KEY = "follow:user:";

    public static final String COMMENT_KEY = "comment:";
    public static final Long COMMENT_TTL= 10L;
    public static final String COMMENT_LIKE_KEY = "comment:liked:";

    public static final String VIDEO_KEY = "video:tag:";
    public static final String USER_LIKE_KEY = "liked:user:";
    public static final String USER_COLLECT_KEY = "collected:user:";
    public static final String FEED_KEY= "feed:user:";
    public static final String VIEW_USER_KEY = "viewed:user:";// 记录用户看过的视频
    public static final String VIEW_VIDEO_KEY = "viewed:video:";// 记录三十分钟内看过该视频的用户

    public static final String CHAT_UNREAD_KEY = "unread:user:";
}
