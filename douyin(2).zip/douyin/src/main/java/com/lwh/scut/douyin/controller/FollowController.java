package com.lwh.scut.douyin.controller;

import com.lwh.scut.douyin.dto.Result;
import com.lwh.scut.douyin.service.FollowService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

@RestController
@RequestMapping("/follow")
public class FollowController {

    @Autowired
    private FollowService followService;

    // 关注用户（包含取消关注功能）
    @PostMapping("/{userId}/{isFollow}")
    public Result follow(@PathVariable Long userId, @PathVariable Boolean isFollow) {
        return followService.follow(userId,isFollow);
    }

    // 查询是否已关注
    @GetMapping("/isFollow/{id}")
    public Result isFollow(@PathVariable Long id) {
        return followService.isFollow(id);
    }

    // 查看自己的关注列表
    @GetMapping("/listFollow/me")
    public Result listFollow() {
        return followService.listFollowOfMe();
    }

    // 查看别人的关注列表
    @GetMapping("/listFollow/{id}")
    public Result listFollow(@PathVariable Long id) {
        return followService.listFollowOfUserId(id);
    }

    // 查看共同关注列表
    @GetMapping("/listCommonFollow/{id}")
    public Result listCommonFollow(@PathVariable Long id) {
        return followService.listCommonFollow(id);
    }
}
