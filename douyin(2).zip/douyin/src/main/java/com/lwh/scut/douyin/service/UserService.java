package com.lwh.scut.douyin.service;

import com.baomidou.mybatisplus.extension.service.IService;
import com.lwh.scut.douyin.dto.Result;
import com.lwh.scut.douyin.dto.UserInfo;
import com.lwh.scut.douyin.entity.User;

public interface UserService extends IService<User> {
    Result sendCodeToLogin(String phone);

    Result sendCodeToRegister(String phone);

    Result loginByCode(String phone, String code);

    Result loginByPassword(String phone, String password);

    Result register(String phone, String code);

    Result registerInfo(UserInfo userInfo);

    Result queryUserById(Long userId);

    Result me();

    Result sign();

    Result signCount();

    Result signCountContinuous();

    Result updateInfo(UserInfo userInfo);
}
