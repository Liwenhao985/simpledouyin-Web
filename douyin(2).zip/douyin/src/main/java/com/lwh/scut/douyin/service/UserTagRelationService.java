package com.lwh.scut.douyin.service;

import com.baomidou.mybatisplus.extension.service.IService;
import com.lwh.scut.douyin.dto.Result;
import com.lwh.scut.douyin.entity.UserTagRelation;

public interface UserTagRelationService extends IService<UserTagRelation> {
    Result addTagWeight(Long tagId);

    Result subTagWeight(Long tagId);
}
