package com.lwh.scut.douyin.service.impl;

import com.baomidou.mybatisplus.core.conditions.query.QueryWrapper;
import com.baomidou.mybatisplus.extension.service.impl.ServiceImpl;
import com.lwh.scut.douyin.entity.ChatMessage;
import com.lwh.scut.douyin.mapper.ChatMessageMapper;
import com.lwh.scut.douyin.service.ChatMessageService;
import com.lwh.scut.douyin.utils.UserHolder;
import com.lwh.scut.douyin.utils.WebSocketUserTracker;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.redis.core.RedisTemplate;
import org.springframework.data.redis.core.StringRedisTemplate;
import org.springframework.messaging.simp.SimpMessagingTemplate;
import org.springframework.stereotype.Service;

import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.Comparator;
import java.util.List;

import static com.lwh.scut.douyin.utils.RedisConstants.CHAT_UNREAD_KEY;
import static io.lettuce.core.GeoArgs.Sort.asc;

@Service
public class ChatMessageServiceImpl extends ServiceImpl<ChatMessageMapper, ChatMessage> implements ChatMessageService {

    @Autowired
    private WebSocketUserTracker webSocketUserTracker; // 假设你有用户在线状态的管理类
    @Autowired
    private SimpMessagingTemplate messagingTemplate;
    @Autowired
    private StringRedisTemplate  stringRedisTemplate;

    // 发送信息
    @Override
    public ChatMessage processSendMessage(ChatMessage message) {
        // 1.保存聊天消息到数据库
        ChatMessage entity = convertToEntity( message);
        save(entity);
        // 2.构造响应消息
        ChatMessage response = convertToEntity( entity);
        // 3.判断接收者是否在线
        boolean isOnline = isUserOnline(message.getReceiverId());
        if (!isOnline) {
            // 4.累加未读消息数
            incrementUnreadCount(message.getSenderId(),message.getReceiverId());
        }
        // 5.发送给接收者
        messagingTemplate.convertAndSendToUser(
                message.getReceiverId().toString(), "/queue/messages", message);

        return response;
    }

    // 判断用户是否在线
    @Override
    public boolean isUserOnline(Long userId) {
        return webSocketUserTracker.isOnline(userId);
    }

    // 增加未读消息数
    @Override
    public void incrementUnreadCount(Long senderId,Long receiverId) {
        String key = CHAT_UNREAD_KEY + receiverId;
        stringRedisTemplate.opsForZSet().incrementScore(key, String.valueOf(senderId), 1);
    }

    @Override
    public void decrementUnreadCount(Long senderId,Long receiverId){
        String key = CHAT_UNREAD_KEY + receiverId;
        stringRedisTemplate.opsForZSet().remove(key, String.valueOf(senderId));
    }

    @Override
    public List<ChatMessage> getChatHistoryOfUser(Long userId) {
        // 1.获取当前登录用户Id
        Long myId = UserHolder.get().getId();
        // 2.获取聊天记录
        List<ChatMessage> history1 = list(new QueryWrapper<ChatMessage>().eq("sender_id", userId).eq("receiver_id", myId));
        List<ChatMessage> history2 = list(new QueryWrapper<ChatMessage>().eq("sender_id", myId).eq("receiver_id", userId));
        // 3.合并history1和history2,按照id顺序排序
        List<ChatMessage> history = new ArrayList<>(history1.stream().sorted(Comparator.comparing(ChatMessage::getId)).toList());
        history.addAll(history2.stream().sorted(Comparator.comparing(ChatMessage::getId)).toList());
        // 4.删去未读缓存
        decrementUnreadCount(userId,myId);
        return history;
    }

    @Override
    public Long getUnreadCountOfUser(Long senderId){
        Long receiverId = UserHolder.get().getId();
        String key = CHAT_UNREAD_KEY + receiverId;
        return stringRedisTemplate.opsForZSet().score(key, String.valueOf(senderId)).longValue();
    }

    @Override
    public Long getTotalUnreadCount(Long userId) {
        String key = CHAT_UNREAD_KEY + userId;
        return stringRedisTemplate.opsForZSet().size(key);
    }

    private ChatMessage convertToEntity(ChatMessage message) {
        ChatMessage entity = new ChatMessage();
        entity.setSenderId(message.getSenderId());
        entity.setReceiverId(message.getReceiverId());
        entity.setContent(message.getContent());
        entity.setCreateTime(message.getCreateTime());
        return entity;
    }
}
