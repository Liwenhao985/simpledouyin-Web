package com.lwh.scut.douyin.utils;

import cn.hutool.core.bean.BeanUtil;
import cn.hutool.core.util.StrUtil;
import com.lwh.scut.douyin.dto.UserDTO;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import org.springframework.data.redis.core.StringRedisTemplate;
import org.springframework.web.servlet.HandlerInterceptor;

import java.util.Map;
import java.util.concurrent.TimeUnit;

import static com.lwh.scut.douyin.utils.RedisConstants.LOGIN_USER_TTL;

public class RefreshInterceptorUtil implements HandlerInterceptor {

    private StringRedisTemplate stringRedisTemplate;
    private static final String LOGIN_USER_KEY = "login:token:";// token的key前缀
    private static final Long LOGIN_CODE_TTL = 30L;// token的过期时间

    public RefreshInterceptorUtil(StringRedisTemplate stringRedisTemplate) {
        this.stringRedisTemplate = stringRedisTemplate;
    }

    //这个拦截器只负责刷新token的过期时间，不进行拦截
    @Override
    public boolean preHandle(HttpServletRequest request, HttpServletResponse response, Object handler) throws Exception {
        //1.获取token,token为空放行
        String token = request.getHeader("authorization");
        if (StrUtil.isBlank(token)) {
            return true;
        }

        //2.获取Redis中的用户
        String tokenKey= LOGIN_USER_KEY + token;
        Map<Object, Object> userMap = stringRedisTemplate.opsForHash().entries(tokenKey);
        //3.判断用户是否存在，用户为空放行
        if (userMap.isEmpty()) {
            return true;
        }

        //7.刷新Redis缓存有效期
        stringRedisTemplate.expire(tokenKey, LOGIN_USER_TTL, TimeUnit.MINUTES);

        return true;
    }

    @Override
    public void afterCompletion(HttpServletRequest request, HttpServletResponse response, Object handler, Exception ex) throws Exception {
        //从ThreadLocal中移除用户
        UserHolder.remove();
    }
}
