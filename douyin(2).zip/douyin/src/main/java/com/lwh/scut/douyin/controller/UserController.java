package com.lwh.scut.douyin.controller;

import com.lwh.scut.douyin.dto.Result;
import com.lwh.scut.douyin.dto.UserInfo;
import com.lwh.scut.douyin.entity.User;
import com.lwh.scut.douyin.service.UserService;
import com.lwh.scut.douyin.utils.UserHolder;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

@RestController
@RequestMapping("/user")
public class UserController {

    @Autowired
    private UserService userService;

    // 发送登陆用的验证码
    @PostMapping("/code1")
    public Result sendCodeToLogin(String phone) {
        return userService.sendCodeToLogin(phone);
    }

    // 发送注册用的验证码
    @PostMapping("/code2")
    public Result sendCodeToRegister(String phone) {
        return userService.sendCodeToRegister(phone);
    }

    // 手机+验证码登录
    @PostMapping("/login/code")
    public Result loginByCode(String phone, String code) {
        return userService.loginByCode(phone, code);
    }

    // 手机+密码登录
    @PostMapping("/login/password")
    public Result loginByPassword(String phone, String password) {
        return userService.loginByPassword(phone, password);
    }

    // 手机号+验证码注册
    @PostMapping("/register")
    public Result register(String phone, String code) {
        return userService.register(phone, code);
    }

    // 初次注册完善用户信息
    @PostMapping("/register/info")
    public Result registerInfo(@RequestBody UserInfo userInfo) {
        return userService.registerInfo(userInfo);
    }

    // 更改用户信息
    @PostMapping("/update")
    public Result updateInfo(@RequestBody UserInfo  userInfo){
        return userService.updateInfo(userInfo);
    }

    //进入别人主页时部分信息展示
    @GetMapping("/{id}")
    public Result queryUserById(@PathVariable("id") Long userId){
        return userService.queryUserById(userId);
    }

    //签到功能
    @PostMapping("/sign")
    public Result sign(){
        return userService.sign();
    }

    //统计签到天数
    @GetMapping("/sign/count")
    public Result signCount(){
        return userService.signCount();
    }

    //统计连续签到天数
    @GetMapping("/sign/count/continuous")
    public Result signCountContinuous(){
        return userService.signCountContinuous();
    }

    //点击“我的”信息展示
    @GetMapping("/me")
    public Result me(){
        return userService.me();
    }
}
