package com.lwh.scut.douyin.service;

import com.baomidou.mybatisplus.extension.service.IService;
import com.lwh.scut.douyin.dto.Result;
import com.lwh.scut.douyin.entity.Comment;

public interface CommentService extends IService<Comment> {
    Result addComment(Long videoId, String content);

    Result deleteComment(Long commentId);

    Result listComment(Long videoId);

    Result replyComment(Long commentId, String content);

    Result likeComment(Long commentId, Boolean isLike);

    Result reportComment(Long commentId,String  reason);

    Result isLiked(Long commentId);
}
