package com.lwh.scut.douyin.configurations;

import com.lwh.scut.douyin.utils.InterceptorUtil;
import com.lwh.scut.douyin.utils.RefreshInterceptorUtil;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Configuration;
import org.springframework.data.redis.core.StringRedisTemplate;
import org.springframework.web.servlet.config.annotation.InterceptorRegistry;
import org.springframework.web.servlet.config.annotation.WebMvcConfigurer;

@Configuration
public class WebConfig implements WebMvcConfigurer {

    @Autowired
    private StringRedisTemplate stringRedisTemplate;

    @Override
    public void addInterceptors(InterceptorRegistry registry) {
        // 访问拦截器
        registry.addInterceptor(new InterceptorUtil())
                .addPathPatterns("/**")
                .excludePathPatterns("/user/code1",
                        "/user/code2",
                        "/user/login/code",
                        "/user/login/password",
                        "/user/register",
                        "/user/register/info")
                .order(1);

        // token刷新拦截器
        registry.addInterceptor(new RefreshInterceptorUtil(stringRedisTemplate))
                .addPathPatterns("/**")
                .excludePathPatterns("/user/code1",
                        "/user/code2",
                        "/user/login/code",
                        "/user/login/password",
                        "/user/register",
                        "/user/register/info")
                .order(0);
    }
}
