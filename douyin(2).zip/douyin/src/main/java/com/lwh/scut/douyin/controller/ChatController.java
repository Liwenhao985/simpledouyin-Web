package com.lwh.scut.douyin.controller;

import com.lwh.scut.douyin.entity.ChatMessage;
import com.lwh.scut.douyin.service.ChatMessageService;
import com.lwh.scut.douyin.utils.UserHolder;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.messaging.handler.annotation.MessageMapping;
import org.springframework.messaging.simp.SimpMessagingTemplate;
import org.springframework.web.bind.annotation.RestController;

import java.text.SimpleDateFormat;
import java.time.LocalDateTime;
import java.util.Date;

@RestController
public class ChatController {
    @Autowired
    private SimpMessagingTemplate messagingTemplate;

    @Autowired
    private ChatMessageService chatMessageService;

    // 发送信息，以及增加未读信息条数
    @MessageMapping("/chat")
    public void sendChatMessage(ChatMessage message) {
        // 发送给发送者（自己）
        messagingTemplate.convertAndSendToUser(
                message.getSenderId().toString(), "/queue/messages", chatMessageService.processSendMessage(message));
    }

    // 获取聊天记录，消除未读信息条数
    @MessageMapping("/chat/history")
    public void getChatHistoryOfUser(Long userId) {
        messagingTemplate.convertAndSendToUser(
                userId.toString(), "/queue/messages", chatMessageService.getChatHistoryOfUser(userId));
    }

    // 获取与某个用户的未读信息条数
    @MessageMapping("/chat/unread")
    public void getUnreadCountOfUser(Long userId) {
        messagingTemplate.convertAndSendToUser(
                userId.toString(), "/queue/messages", chatMessageService.getUnreadCountOfUser(userId));
    }

    // 获取总的未读信息条数
    @MessageMapping("/chat/totalUnread")
    public void getTotalUnreadCount() {
        Long userId= UserHolder.get().getId();
        messagingTemplate.convertAndSendToUser(
                userId.toString(), "/queue/messages", chatMessageService.getTotalUnreadCount(userId));
    }
}
