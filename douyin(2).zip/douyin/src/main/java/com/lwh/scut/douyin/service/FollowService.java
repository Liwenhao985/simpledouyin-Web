package com.lwh.scut.douyin.service;

import com.baomidou.mybatisplus.extension.service.IService;
import com.lwh.scut.douyin.dto.Result;
import com.lwh.scut.douyin.entity.Follow;

public interface FollowService extends IService<Follow> {
    Result follow(Long userId,Boolean isFollow);

    Result isFollow(Long id);

    Result listFollowOfMe();

    Result listFollowOfUserId(Long id);

    Result listCommonFollow(Long id);
}
