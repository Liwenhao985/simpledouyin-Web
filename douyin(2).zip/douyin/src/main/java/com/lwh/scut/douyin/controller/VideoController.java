package com.lwh.scut.douyin.controller;

import com.lwh.scut.douyin.dto.Result;
import com.lwh.scut.douyin.dto.VideoInfo;
import com.lwh.scut.douyin.entity.Video;
import com.lwh.scut.douyin.service.UserService;
import com.lwh.scut.douyin.service.VideoService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

@RestController
@RequestMapping("/video")
public class VideoController {

    @Autowired
    private VideoService videoService;

    // 发布视频
    @PostMapping("/publish")
    public Result saveVideo(@RequestBody VideoInfo videoInfo) {
        return videoService.saveVideo(videoInfo);
    }

    // 删除视频
    @DeleteMapping("/delete/{id}")
    public Result deleteVideo(@PathVariable Long id) {
        return videoService.deleteVideo(id);
    }

    // 给视频点赞
    @PutMapping("/like/{id}")
    public Result likeVideo(@PathVariable Long id) {
        return videoService.likeVideo(id);
    }

    // 判断是否已点赞
    @GetMapping("/isLike/{id}")
    public Result isLikeVideo(@PathVariable Long id) {
        return videoService.isLikeVideo(id);
    }

    // 收藏视频
    @PutMapping("/collect/{id}")
    public Result collectVideo(@PathVariable Long id) {
        return videoService.collectVideo(id);
    }

    // 判断是否已收藏
    @GetMapping("/isCollect/{id}")
    public Result isCollectVideo(@PathVariable Long id) {
        return videoService.isCollectVideo(id);
    }

    // 根据用户喜好获取推荐视频ID列表（存储到redis，不返回）
    @GetMapping("/recommend")
    public Result listRecommendVideo() {
        return videoService.recommend();
    }

    // 在自己主页中展示自己发布过的视频（一般较少，不分页）
    @GetMapping("/list/me")
    public Result listMyVideo() {
        return videoService.listMyVideo();
    }

    // 在自己主页按时间顺序展示点赞过的视频（分页）
    @GetMapping("/list/like")
    public Result listLikeVideo(@RequestParam("lastId") Long max, @RequestParam(value = "offset", defaultValue = "0") Integer offset) {
        return videoService.listLikeVideo(max, offset);
    }

    // 在自己主页按时间顺序展示收藏的视频（分页）
    @GetMapping("/list/collect")
    public Result listCollectVideo(@RequestParam("lastId") Long max, @RequestParam(value = "offset", defaultValue = "0") Integer offset) {
        return videoService.listCollectVideo(max, offset);
    }

    // 在别人主页展示别人发布过的视频（分页）
    @GetMapping("/list/{id}")
    public Result queryVideoByUserId(@PathVariable Long Id,
                                     @RequestParam("lastId") Long max, @RequestParam(value = "offset", defaultValue = "0") Integer offset) {
        return videoService.listOtherVideo(Id, max, offset);
    }

    // 关注的人的视频（分页）（Feed流推模型+redis）
    @GetMapping("/list/follow")
    public Result listFollowVideo(@RequestParam("lastId") Long max, @RequestParam(value = "offset", defaultValue = "0") Integer offset) {
        return videoService.listFollowVideo(max, offset);
    }

    // 获取特定视频资源(例如在主页点击的视频）
    @GetMapping("/{id}")
    public Result getVideoById(@PathVariable Long id) {
        return videoService.getVideoById(id);
    }
}
