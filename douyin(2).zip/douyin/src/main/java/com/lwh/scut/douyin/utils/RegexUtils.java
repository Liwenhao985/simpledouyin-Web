package com.lwh.scut.douyin.utils;

import cn.hutool.core.util.StrUtil;

// 正则相关工具类,校验手机号、邮箱等格式是否规范
public class RegexUtils {

    // 校验手机号是否符合规范
    public static boolean isPhoneInvalid(String phone){
        return mismatch(phone, RegexPatterns.PHONE_REGEX);
    }

    // 校验邮箱是否符合规范
    public static boolean isEmailInvalid(String email){
        return mismatch(email, RegexPatterns.EMAIL_REGEX);
    }


    // 校验验证码是否符合规范
    public static boolean isCodeInvalid(String code){
        return mismatch(code, RegexPatterns.VERIFY_CODE_REGEX);
    }

    // 校验是否不符合正则格式
    private static boolean mismatch(String str, String regex){
        if (StrUtil.isBlank(str)) {
            return true;
        }
        return !str.matches(regex);
    }
}
