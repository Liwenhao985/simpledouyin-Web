package com.lwh.scut.douyin.controller;

import com.lwh.scut.douyin.dto.Result;
import com.lwh.scut.douyin.utils.AliyunOSSOperator;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.multipart.MultipartFile;

@RestController
@RequestMapping("/upload")
public class UploadController {

    @Autowired
    private AliyunOSSOperator aliyunOSSOperator;

    // 上传资源
    @PostMapping
    public Result upload(MultipartFile  file) throws Exception {
        return aliyunOSSOperator.upload(file.getOriginalFilename(),file.getBytes());
    }
}
