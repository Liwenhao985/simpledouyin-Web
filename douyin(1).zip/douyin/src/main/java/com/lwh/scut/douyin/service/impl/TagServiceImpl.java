package com.lwh.scut.douyin.service.impl;

import cn.hutool.json.JSONUtil;
import com.baomidou.mybatisplus.extension.service.impl.ServiceImpl;
import com.lwh.scut.douyin.dto.Result;
import com.lwh.scut.douyin.entity.Tag;
import com.lwh.scut.douyin.mapper.TagMapper;
import com.lwh.scut.douyin.service.TagService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.redis.core.StringRedisTemplate;
import org.springframework.stereotype.Service;

import java.util.List;

import static com.lwh.scut.douyin.utils.RedisConstants.TAG_KEY;
import static com.lwh.scut.douyin.utils.RedisConstants.TAG_TTL;

@Service
public class TagServiceImpl extends ServiceImpl<TagMapper, Tag> implements TagService {

    @Autowired
    private StringRedisTemplate stringRedisTemplate;

    @Override
    public Result saveTag(String tag) {
        // 1.保存标签到数据库
        Tag tag1 = new Tag(null, tag, null);
        boolean save = save(tag1);
        // 2.保存成功则刷新redis数据
        if (save) {
            List<Tag> list = query().list();
            stringRedisTemplate.opsForValue().set(TAG_KEY, JSONUtil.toJsonStr(list));
        }
        return save ? Result.success("保存标签成功") : Result.error("保存标签失败");
    }

    @Override
    public Result deleteTag(Long id) {
        // 1.删除标签
        boolean removeById = removeById(id);
        // 2.刷新redis数据
        if (removeById) {
            List<Tag> list = query().list();
            stringRedisTemplate.opsForValue().set(TAG_KEY, JSONUtil.toJsonStr(list));
        }
        return removeById ? Result.success("删除标签成功") : Result.error("删除标签失败");
    }

    @Override
    public Result listTag(){
        //1.检查redis缓存数据
        String s = stringRedisTemplate.opsForValue().get(TAG_KEY);
        if (s != null) {
            //有则返回
            List<Tag> list = JSONUtil.toList(s, Tag.class);
            return Result.success(list);
        }
        //2.没有则查数据库
        List<Tag> list = query().list();
        if (list == null) {
            //3.没有则报错
            return Result.error("Tag不存在");
        }
        //4.有，缓存到redis
        stringRedisTemplate.opsForValue().set(TAG_KEY, JSONUtil.toJsonStr(list));
        stringRedisTemplate.expire(TAG_KEY, TAG_TTL, java.util.concurrent.TimeUnit.SECONDS);
        return Result.success(list);
    }
}
