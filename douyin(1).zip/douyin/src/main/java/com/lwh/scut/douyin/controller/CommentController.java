package com.lwh.scut.douyin.controller;

import com.lwh.scut.douyin.dto.Result;
import com.lwh.scut.douyin.service.CommentService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

@RestController
@RequestMapping("/comment")
public class CommentController {

    @Autowired
    private CommentService commentService;

    // 在视频添加评论
    @PostMapping("/add/{id}")
    public Result addComment(@PathVariable Long id, String content) {
        return commentService.addComment(id, content);
    }

    // 删除评论
    @DeleteMapping("/delete/{id}")
    public Result deleteComment(@PathVariable Long id) {
        return commentService.deleteComment(id);
    }

    // 获取视频的评论列表(按点赞数排序）
    @GetMapping("/list/{id}")
    public Result listComment(@PathVariable Long id) {
        return commentService.listComment(id);
    }

    // 回复评论
    @PostMapping("/reply/{id}")
    public Result replyComment(@PathVariable Long id, String content) {
        return commentService.replyComment(id, content);
    }

    // 点赞评论
    @PutMapping("/like/{id}/{isLike}")
    public Result likeComment(@PathVariable Long id, @PathVariable Boolean isLike) {
        return commentService.likeComment(id, isLike);
    }

    // 判断是否已点赞
    @GetMapping("/isLiked/{id}")
    public Result isLiked(@PathVariable Long id) {
        return commentService.isLiked(id);
    }

    // 举报评论
    @PutMapping("/report/{id}/{reason}")
    public Result reportComment(@PathVariable Long id, @PathVariable String reason) {
        return commentService.reportComment(id, reason);
    }
}
