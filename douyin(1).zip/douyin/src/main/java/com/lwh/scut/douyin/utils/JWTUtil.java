package com.lwh.scut.douyin.utils;

import com.lwh.scut.douyin.dto.UserDTO;
import io.jsonwebtoken.Claims;
import io.jsonwebtoken.Jwts;
import io.jsonwebtoken.SignatureAlgorithm;
import io.jsonwebtoken.security.Keys;

import java.security.Key;
import java.util.Date;
import java.util.Map;

// JWT工具类，生成、解析JWT令牌
public class JWTUtil {

    // 自动生成一个安全的密钥（256位）
    private static final Key SECRET_KEY = Keys.secretKeyFor(SignatureAlgorithm.HS256);
    private static final long EXPIRATION = 3600000;

    //接收业务数据，生成token并返回
    // 这个claims封装的是用户信息
    public static String createToken(Map<String, Object> claims) {
        return Jwts.builder()
                .setClaims(claims)
                .signWith(SignatureAlgorithm.HS256, SECRET_KEY)
                .setExpiration(new Date(System.currentTimeMillis() + EXPIRATION))
                .compact();
    }

    //验证token,并返回业务数据
    public static Map<String, Object> parseToken(String token) {
        // 在过滤器中解析 token
        Claims claims = Jwts.parser()
                .setSigningKey(SECRET_KEY)
                .parseClaimsJws(token)
                .getBody();
        System.out.println( claims);
        // 将claims转换为UserDTO
        System.out.println( claims.get("id")+ " " + claims.get("nickName")+ " " + claims.get("image"));
        UserDTO userDTO = new UserDTO(claims.get("id").toString(), claims.get("nickName").toString(), claims.get("image").toString());
        System.out.println(userDTO);
        UserHolder.set(userDTO);
        return claims;
    }
}
