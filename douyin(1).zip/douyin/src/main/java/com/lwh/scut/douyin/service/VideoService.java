package com.lwh.scut.douyin.service;

import com.baomidou.mybatisplus.extension.service.IService;
import com.lwh.scut.douyin.dto.Result;
import com.lwh.scut.douyin.dto.VideoInfo;
import com.lwh.scut.douyin.entity.Video;

public interface VideoService extends IService<Video> {
    Result saveVideo(VideoInfo videoInfo);

    Result deleteVideo(Long id);

    Result likeVideo(Long id);

    Result isLikeVideo(Long id);

    Result collectVideo(Long id);

    Result isCollectVideo(Long id);

    Result recommend();

    Result listMyVideo();

    Result listLikeVideo(Long max, Integer offset);

    Result listCollectVideo(Long max, Integer offset);

    Result listOtherVideo(Long id, Long max, Integer offset);

    Result getVideoById(Long id);

    Result listFollowVideo(Long max, Integer offset);
}
