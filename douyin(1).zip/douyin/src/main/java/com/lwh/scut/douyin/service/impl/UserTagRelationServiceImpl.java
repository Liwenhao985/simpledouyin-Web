package com.lwh.scut.douyin.service.impl;


import com.baomidou.mybatisplus.core.conditions.query.QueryWrapper;
import com.baomidou.mybatisplus.core.conditions.update.UpdateWrapper;
import com.baomidou.mybatisplus.extension.conditions.query.QueryChainWrapper;
import com.baomidou.mybatisplus.extension.service.impl.ServiceImpl;
import com.lwh.scut.douyin.dto.Result;
import com.lwh.scut.douyin.entity.UserTagRelation;
import com.lwh.scut.douyin.mapper.UserTagRelationMapper;
import com.lwh.scut.douyin.service.UserTagRelationService;
import com.lwh.scut.douyin.utils.UserHolder;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

@Service
public class UserTagRelationServiceImpl extends ServiceImpl<UserTagRelationMapper, UserTagRelation> implements UserTagRelationService {

    @Autowired
    private UserTagRelationMapper userTagRelationMapper;

    @Override
    public Result addTagWeight(Long tagId){
        addWeight(tagId,true);
        return Result.success();
    }

    @Override
    public Result subTagWeight(Long tagId){
        addWeight(tagId,false);
        return Result.success();
    }

    private void addWeight(Long tagId,Boolean isAdd){
        // 1.获取当前登录用户ID
        long myId = UserHolder.get().getId();
        if(isAdd){
            // 2.直接让weight+1
            userTagRelationMapper.update(null,new UpdateWrapper<UserTagRelation>().setSql("weight=weight+1").eq("tag_id",tagId).eq("user_id",myId));
        }else{
            userTagRelationMapper.update(null,new UpdateWrapper<UserTagRelation>().setSql("weight=weight-1").eq("tag_id",tagId).eq("user_id",myId));
        }
    }
}
