package com.lwh.scut.douyin.configurations;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.fasterxml.jackson.datatype.jsr310.JavaTimeModule;
import io.jsonwebtoken.Jwts;
import io.jsonwebtoken.SignatureAlgorithm;
import io.jsonwebtoken.io.Decoders;
import io.jsonwebtoken.io.Deserializer;
import io.jsonwebtoken.io.Encoders;
import io.jsonwebtoken.io.Serializer;
import io.jsonwebtoken.jackson.io.JacksonDeserializer;
import io.jsonwebtoken.jackson.io.JacksonSerializer;
import io.jsonwebtoken.security.Keys;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

import javax.crypto.SecretKey;
import java.time.LocalDateTime;
import java.util.Date;

@Configuration
public class JwtConfig {

    private final SecretKey key = Keys.secretKeyFor(SignatureAlgorithm.HS256);

    // ========== 序列化器：用于生成 JWT（.compact()） ==========
    @Bean
    public Serializer<Object> jwtSerializer() {
        ObjectMapper objectMapper = new ObjectMapper();
        objectMapper.registerModule(new JavaTimeModule()); // 支持 LocalDateTime
        return new JacksonSerializer<>(objectMapper);
    }

    // ========== 反序列化器：用于解析 JWT（.parseClaimsJws()） ==========
    @Bean
    public Deserializer<Object> jwtDeserializer() {
        ObjectMapper objectMapper = new ObjectMapper();
        objectMapper.registerModule(new JavaTimeModule()); // 同样需要注册
        return new JacksonDeserializer<>(objectMapper);
    }

    // ========== JWT 签名密钥 ==========
    @Bean
    public SecretKey jwtSecretKey() {
        return key;
    }
}