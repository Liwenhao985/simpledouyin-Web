package com.lwh.scut.douyin.controller;

import com.lwh.scut.douyin.dto.Result;
import com.lwh.scut.douyin.service.UserTagRelationService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

@RestController
@RequestMapping("/userTagRelation")
public class UserTagRelation {

    @Autowired
    private UserTagRelationService userTagRelationService;

    // 增加用户与视频对应的标签的权重weight（原先不存在则创建）
    @PutMapping("/add/{tagId}")
    public Result addUserTagRelation(@PathVariable Long tagId) {
        return userTagRelationService.addTagWeight(tagId);
    }

    // 减少用户与视频对应的标签的权重weight
    @PutMapping("/sub/{tagId}")
    public Result subUserTagRelation(@PathVariable Long tagId) {
        return userTagRelationService.subTagWeight(tagId);
    }
}
