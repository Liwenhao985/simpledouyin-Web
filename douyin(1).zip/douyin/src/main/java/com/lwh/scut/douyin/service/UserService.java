package com.lwh.scut.douyin.service;

import com.baomidou.mybatisplus.extension.service.IService;
import com.lwh.scut.douyin.dto.Result;
import com.lwh.scut.douyin.dto.UserInfo;
import com.lwh.scut.douyin.entity.User;

public interface UserService extends IService<User> {
    Result sendCode(String phone);

    Result loginWithPhone(String phone, String code);

    Result queryUserById(Long userId);

    Result me();

    Result sign();

    Result signCount();

    Result signCountContinuous();

    Result updateInfo(UserInfo userInfo);

    Result loginWithPassword(String phone, String password);
}
