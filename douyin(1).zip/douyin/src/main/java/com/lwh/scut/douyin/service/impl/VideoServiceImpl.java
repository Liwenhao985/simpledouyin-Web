package com.lwh.scut.douyin.service.impl;

import cn.hutool.core.util.StrUtil;
import com.baomidou.mybatisplus.core.conditions.query.QueryWrapper;
import com.baomidou.mybatisplus.extension.service.impl.ServiceImpl;
import com.lwh.scut.douyin.dto.Result;
import com.lwh.scut.douyin.dto.ScrollResult;

import com.lwh.scut.douyin.dto.VideoInfo;
import com.lwh.scut.douyin.entity.*;
import com.lwh.scut.douyin.mapper.UserMapper;
import com.lwh.scut.douyin.mapper.VideoMapper;
import com.lwh.scut.douyin.service.*;
import com.lwh.scut.douyin.utils.UserHolder;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Lazy;
import org.springframework.data.redis.core.StringRedisTemplate;
import org.springframework.data.redis.core.ZSetOperations;
import org.springframework.stereotype.Service;

import java.util.*;
import java.util.concurrent.TimeUnit;

import static com.lwh.scut.douyin.utils.RedisConstants.*;

@Service
public class VideoServiceImpl extends ServiceImpl<VideoMapper, Video> implements VideoService {

    @Autowired
    private UserService userService;
    @Autowired
    private FollowService followService;
    @Lazy
    @Autowired
    private CommentService commentService;
    @Autowired
    private UserTagRelationService userTagRelationService;
    @Autowired
    private StringRedisTemplate stringRedisTemplate;

    @Override
    public Result saveVideo(VideoInfo videoInfo) {
        // 1.封装video对象
        Video video = newVideo(videoInfo);
        // 2.保存视频
        boolean save = save(video);
        if (!save) {
            return Result.error("发布视频失败");
        }
        // 3.把videoId缓存到对应的tagKey中（即缓存这个tag对应的视频ID）
        stringRedisTemplate.opsForZSet().add(VIDEO_KEY + videoInfo.getTagId(), video.getId().toString(),getHot( video));
        // 4.获取自己的粉丝Ids
        List<Follow> fans = followService.query().eq("follow_id", UserHolder.get().getId()).list();
        for (Follow fan : fans) {
            // 5.给粉丝推荐视频
            stringRedisTemplate.opsForZSet().add(FEED_KEY + fan.getUserId(), video.getId().toString(), System.currentTimeMillis());
        }
        // 返回结果
        return Result.success("发布视频成功");
    }

    @Override
    public Result deleteVideo(Long id) {
        if (!isExist(id)) {
            return Result.error("视频不存在");
        }
        Video video = getById(id);
        if (!video.getUserId().equals(UserHolder.get().getId())) {
            return Result.error("您没有权限删除该视频");
        }
        // 1.删除视频
        boolean remove = removeById(id);
        if (!remove) {
            return Result.error("删除失败");
        }
        // 2.删除视频标签缓存
        stringRedisTemplate.opsForZSet().remove(VIDEO_KEY + video.getTagId(), id.toString());
        // 3.删除评论缓存与数据库数据
        stringRedisTemplate.delete(COMMENT_KEY + id);
        commentService.remove(new QueryWrapper<Comment>().eq("video_id", id));
        return Result.success("删除成功");
    }

    @Override
    public Result likeVideo(Long id) {
        if (!isExist(id)) {
            return Result.error("视频不存在");
        }
        // 1.获取当前登录用户ID
        long myId = UserHolder.get().getId();
        // 2.判断当前用户是否已经点赞(ZSet存储，score值为时间戳)
        String key = USER_LIKE_KEY + myId;
        Long rank = stringRedisTemplate.opsForZSet().rank(key, String.valueOf(id));
        if (rank != null && rank >= 0) {
            // 3.取消点赞
            stringRedisTemplate.opsForZSet().remove(key, String.valueOf(id));
            updateVideoCountOfLike(id,false);
            return Result.success();
        }
        // 4.点赞
        stringRedisTemplate.opsForZSet().add(key, String.valueOf(id), System.currentTimeMillis());
        updateVideoCountOfLike(id,true);
        return Result.success("点赞成功");
    }

    @Override
    public Result isLikeVideo(Long id) {
        if (!isExist(id)) {
            return Result.error("视频不存在");
        }
        // 1.获取当前登录用户ID
        long myId = UserHolder.get().getId();
        // 2.判断当前用户是否已经点赞
        String key = USER_LIKE_KEY + myId;
        Long rank = stringRedisTemplate.opsForZSet().rank(key, String.valueOf(id));
        return Result.success(rank != null && rank >= 0);
    }

    @Override
    public Result collectVideo(Long id) {
        if (!isExist(id)) {
            return Result.error("视频不存在");
        }
        // 1.获取当前登录用户ID
        long myId = UserHolder.get().getId();
        // 2.判断当前用户是否已经收藏
        String key = USER_COLLECT_KEY + myId;
        Long rank = stringRedisTemplate.opsForZSet().rank(key, String.valueOf(id));
        if (rank != null && rank >= 0) {
            // 3.取消收藏
            stringRedisTemplate.opsForZSet().remove(key, String.valueOf(id));
            updateVideoCountOfCollect(id,false);
        }
        // 4.收藏
        stringRedisTemplate.opsForZSet().add(key, String.valueOf(id), System.currentTimeMillis());
        updateVideoCountOfCollect(id,true);
        return Result.success();
    }

    @Override
    public Result isCollectVideo(Long id) {
        if (!isExist(id)) {
            return Result.error("视频不存在");
        }
        // 1.获取当前登录用户ID
        long myId = UserHolder.get().getId();
        // 2.判断当前用户是否已经收藏
        String key = USER_COLLECT_KEY + myId;
        Long rank = stringRedisTemplate.opsForZSet().rank(key, String.valueOf(id));
        return Result.success(rank != null && rank >= 0);
    }

    @Override
    public Result recommend() {
        // 1.获取当前登录用户ID
        long myId = UserHolder.get().getId();
        // 2.获取userTagRelations
        List<UserTagRelation> userTagRelations = userTagRelationService.list(new QueryWrapper<UserTagRelation>().eq("user_id", myId));
        // 3.从userTagRelations中获取用户常看视频标签和对应的weight,并记录weight之和
        Map<Long, Long> userPreference = new HashMap<>();
        Long sum=0L;
        for (UserTagRelation userTagRelation : userTagRelations) {
            userPreference.put(userTagRelation.getTagId(), userTagRelation.getWeight());
            sum += userTagRelation.getWeight();
        }
        // 4.获取用户看过的视频IdList
        List<Long> viewedVideoIdsList= new ArrayList<>();
        Set<String> viewedVideoIds = stringRedisTemplate.opsForZSet().range(VIEW_USER_KEY + myId, 0, -1);
        if(viewedVideoIds != null){
            viewedVideoIdsList = viewedVideoIds.stream().map(Long::parseLong).toList();
        }
        // 5.生成推荐视频List,一次推送50个视频左右
        List<Video> recommendVideoList = new ArrayList<>();
        for (Long tagId : userPreference.keySet()) {
            // 6.改标签视频数
            int count = Math.toIntExact(userPreference.get(tagId) / sum * 50);
            int countOfRecommend=0;// 记录加入recommendVideoList的个数（方便去重的同时减少访问数据库的次数)
            int offset=0;// 获取该标签下的视频Id的偏移量
            while(countOfRecommend < count) {
                // 7.获取该标签下的视频Id
                List<String> videoIds = (List<String>) stringRedisTemplate.opsForZSet().range(VIDEO_KEY + tagId, offset, count);
                if (videoIds == null || videoIds.isEmpty()) {
                    break;// 获取该标签下的视频Id为空或已经遍历完但数量仍不够，跳出循环
                }
                // 8.判断该视频Id是否已经加入recommendVideoList
                for (String videoId : videoIds) {
                    if (!viewedVideoIdsList.contains(Long.parseLong(videoId))) {
                        // 9.加入recommendVideoList
                        Video video = getById(Long.parseLong(videoId));
                        recommendVideoList.add(video);
                        countOfRecommend++;
                    }
                }
                offset += videoIds.size();
            }
        }
        return Result.success(recommendVideoList);
    }

    @Override
    public Result listMyVideo() {
        // 一版发布较少，所以不进行缓存和分页
        // 1.获取当前登录用户ID
        long myId = UserHolder.get().getId();
        List< Video> videoList = list(new QueryWrapper< Video>().eq("user_id", myId));
        return Result.success(videoList);
    }

    @Override
    public Result listLikeVideo(Long max, Integer offset){
        // 1.获取当前登录用户ID
        long myId = UserHolder.get().getId();
        // 2.获取当前用户点赞的视频Id
        String key = USER_LIKE_KEY + myId;
        ScrollResult scrollResult = getScrollResult(key, max, offset);
        return Result.success(scrollResult);
    }

    @Override
    public Result listCollectVideo(Long max, Integer offset) {
        // 1.获取当前登录用户ID
        long myId = UserHolder.get().getId();
        // 2.获取当前用户收藏的视频Id
        String key = USER_COLLECT_KEY + myId;
        ScrollResult scrollResult = getScrollResult(key, max, offset);
        return Result.success(scrollResult);
    }

    @Override
    public Result listOtherVideo(Long id, Long max, Integer offset) {
        List< Video> videoList = list(new QueryWrapper< Video>().eq("user_id", id));
        return Result.success(videoList);
    }

    @Override
    public Result listFollowVideo(Long max, Integer offset) {
        // 1.获取当前登录用户ID
        long myId = UserHolder.get().getId();
        // 2.获取缓存feed的videoIds
        String key = FEED_KEY + myId;
        ScrollResult scrollResult = getScrollResult(key, max, offset);
        return Result.success(scrollResult);
    }

    @Override
    public Result getVideoById(Long id) {
        Video video = getById(id);
        if (video == null){
            return Result.error("视频不存在");
        }
        queryVideoUser(video);
        queryVideoIsLiked(video);
        queryVideoIsCollected(video);
        // 获取当前登录用户Id
        long myId = UserHolder.get().getId();
        // 检查用户30分钟内是否已经看过该视频，如果已经看过则不增加播放量
        if (!Boolean.TRUE.equals(stringRedisTemplate.opsForSet().isMember(VIEW_VIDEO_KEY + id, String.valueOf(myId)))) {
            // 30分钟内未看过，统计播放量
            video.setCountOfBroadcast(video.getCountOfBroadcast() + 1);
            updateById(video);;
            stringRedisTemplate.opsForSet().add(VIEW_VIDEO_KEY + id, String.valueOf(myId));// 记录30分钟内已观看该视频的用户
        }
        stringRedisTemplate.opsForSet().add(VIEW_USER_KEY + myId, String.valueOf(id));// 记录用户已观看该视频
        stringRedisTemplate.expire(VIEW_VIDEO_KEY + id, 30, TimeUnit.MINUTES);
        return Result.success(video);
    }

    private Boolean isExist(Long id) {
        Video video = getById(id);
        if (video == null) {
            return false;
        }
        return true;
    }

    private Video newVideo(VideoInfo videoInfo) {
        Long userId = UserHolder.get().getId() ;
        Video video = new Video();
        video.setUserId(userId);
        video.setTagId(videoInfo.getTagId());
        video.setUrl(videoInfo.getUrl());
        video.setTitle(videoInfo.getTitle());
        return video;
    }

    private Long getHot(Video  video){
        return (long) (video.getCountOfLiked()*0.4 + video.getCountOfCollect()*0.5 + video.getCountOfBroadcast()*0.1);
    }

    private void updateVideoCountOfLike(Long videoId,Boolean isLike) {
        Video video = getById(videoId);
        if (video == null) {
            return;
        }
        if (isLike) {
            video.setCountOfLiked(video.getCountOfLiked() + 1);
        }else {
            video.setCountOfLiked(video.getCountOfLiked() - 1);
        }
        updateById(video);
    }

    private void updateVideoCountOfCollect(Long id, boolean b) {
        Video video = getById(id);
        if (video == null) {
            return;
        }
        if (b) {
            video.setCountOfCollect(video.getCountOfCollect() + 1);
        }else {
            video.setCountOfCollect(video.getCountOfCollect() - 1);
        }
        updateById(video);
    }

    private void queryVideoUser(Video  video){
        User user = userService.getById(video.getUserId());
        video.setSenderName(user.getNickName());
        video.setSenderImage(user.getImage());
    }

    private void queryVideoIsLiked(Video  video){
        Long myId = UserHolder.get().getId();
        String key = USER_LIKE_KEY + myId;
        Long rank = stringRedisTemplate.opsForZSet().rank(key, String.valueOf(video.getId()));
        video.setIsLiked(rank != null && rank >= 0);
    }

    private void queryVideoIsCollected(Video  video){
        Long myId = UserHolder.get().getId();
        String key = USER_COLLECT_KEY + myId;
        Long rank = stringRedisTemplate.opsForZSet().rank(key, String.valueOf(video.getId()));
        video.setIsCollected(rank != null && rank >= 0);
    }

    private ScrollResult getScrollResult(String key, Long max, Integer offset){
        Set<ZSetOperations.TypedTuple<String>> typedTuples = stringRedisTemplate.opsForZSet()
                .reverseRangeByScoreWithScores(key, 0, max, offset, 10);
        if (typedTuples == null || typedTuples.isEmpty()) {
            return null;
        }
        // 3.一个一个读取，并记录offset和 max
        List<Long> ids = new ArrayList<>(typedTuples.size());//直接创建足够的空间
        long minTime = 0;
        int os = 1;
        for (ZSetOperations.TypedTuple<String> tuple : typedTuples) {
            // 3.1.获取id
            ids.add(Long.valueOf(tuple.getValue()));
            // 3.2.获取分数(时间戳）
            long time = tuple.getScore().longValue();
            if(time == minTime){
                os++;
            }else{
                minTime = time;
                os = 1;
            }
        }
        // 4.根据id查询blog,注意顺序
        String idStr = StrUtil.join(",", ids);
        List<Video> videos = query().in("id", ids).last("ORDER BY FIELD(id," + idStr + ")").list();
        videos.forEach(video -> {
            // 4.1.查询blog的作者头像与昵称
            queryVideoUser(video);
            // 4.2.查询blog是否被点赞
            queryVideoIsLiked(video);
            // 4.3.查询blog是否被收藏
            queryVideoIsCollected(video);
        });
        return new ScrollResult(videos, minTime, os);
    }
}
