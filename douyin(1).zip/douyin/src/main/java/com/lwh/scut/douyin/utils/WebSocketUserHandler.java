package com.lwh.scut.douyin.utils;

import com.lwh.scut.douyin.dto.YourCustomPrincipal;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.event.EventListener;
import org.springframework.messaging.simp.stomp.StompHeaderAccessor;
import org.springframework.stereotype.Component;
import org.springframework.web.socket.messaging.SessionConnectedEvent;
import org.springframework.web.socket.messaging.SessionDisconnectEvent;

import java.security.Principal;

@Component
public class WebSocketUserHandler {

    @Autowired
    private WebSocketUserTracker webSocketUserTracker;

    @EventListener
    public void handleWebSocketConnect(SessionConnectedEvent event) {
        StompHeaderAccessor accessor = StompHeaderAccessor.wrap(event.getMessage());
        Principal principal = accessor.getUser();
        if (principal instanceof YourCustomPrincipal) {
            Long userId = ((YourCustomPrincipal) principal).getId();
            webSocketUserTracker.userOnline(userId);
        }
    }

    @EventListener
    public void handleWebSocketDisconnect(SessionDisconnectEvent event) {
        StompHeaderAccessor accessor = StompHeaderAccessor.wrap(event.getMessage());
        Principal principal = accessor.getUser();
        if (principal instanceof YourCustomPrincipal) {
            Long userId = ((YourCustomPrincipal) principal).getId();
            webSocketUserTracker.userOffline(userId);
        }
    }
}