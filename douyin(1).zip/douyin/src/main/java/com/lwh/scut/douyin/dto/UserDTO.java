package com.lwh.scut.douyin.dto;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@AllArgsConstructor
@NoArgsConstructor
public class UserDTO {
    private Long id;
    private String nickName;
    private String image;

    public UserDTO(String id, String subject, String icon) {
        this.id = Long.valueOf(id);
        this.nickName = subject;
        this.image = icon;
    }
}
